SIMPLE MODERN POS SYSTEM USING PHP/CODEIGNITER V1.0


Features:
-Admin Panel
-Employee Panel
-Supplier Management
-Units and Types Setup
-Stock Goods Management
-Maintain Incoming Goods (Purchase)
-Manages Outgoing Goods (Sales)
-Discounts
-Generate Invoices
-Fetch and Download Reports
-User Settings
-User Management
-Activate/Deactivate Users
-Graphical Representation
-Total Earnings Till Date
-Minimum Goods Stock Overview
-Top Recent Purchase Transaction Overview
-Top Recent Sales Transaction Overview

Bugs (still fixing):
-Showing an error in change user credentials


**Database Name: igniterpos** (just create database name and import it)

**Recommended PHP Version 5.6.3 or up**


**Admin Login Details**

Username: admin
Password: Password@123

**Developed by MacoyTzy, Y4KNU and DosKike**